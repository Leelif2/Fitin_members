---
description: 새 화면을 Nocturne 규칙에 맞춰 추가한다
---

새 화면을 만들기 전에 반드시:

1. `CLAUDE.md`의 디자인 규칙을 다시 읽는다.
2. `Fitin Main.dc.html`과 `Fitin Auth.dc.html`을 읽어 섹션 구조, 간격, 카드·버튼·태그 사용법, 영/한 병기 방식을 파악한다.
3. `_ds/nocturne-*/styles.css`에서 쓸 토큰과 컴포넌트 클래스를 확인한다.

그 다음 같은 패턴으로 새 파일을 만든다. 컨테이너 `max-width:1180px`, 좌우 `padding:24px`, 섹션 리듬 64px, 다단은 전부 `repeat(auto-fit, minmax(…,1fr))`.

완료하면 `/save`로 커밋·푸시한다.
