# Fitin — VSCode + Git 자동 저장 워크플로우

한 번만 설정하면, 파일은 VSCode가 알아서 저장하고, 커밋·푸시하면 GitHub Pages에 자동 배포됩니다.

## 1. 최초 설정 (한 번만)

```bash
git clone https://github.com/Leelif2/Fitin_members.git
cd Fitin_members
# 이 프로젝트 파일 전체를 이 폴더에 복사 (다운로드한 zip 압축 해제)
chmod +x scripts/*.sh
code .
```

VSCode가 열리면 우하단에 "권장 확장 프로그램 설치" 알림이 뜹니다 — 설치하세요 (GitLens, Live Server, Prettier, Claude Code).

GitHub Pages 켜기: repo → Settings → Pages → Source를 **GitHub Actions**로 설정.

## 2. 3단계 자동 저장

### 1단계 — 파일 자동 저장 (설정 완료됨)
`.vscode/settings.json`에서 `files.autoSave: afterDelay` (0.8초). 타이핑을 멈추면 디스크에 저장됩니다. Cmd+S 누를 필요 없음.

### 2단계 — 커밋 후 자동 푸시 (설정 완료됨)
`git.postCommitCommand: "push"` — VSCode 소스 제어 패널에서 커밋하면 푸시가 자동으로 따라갑니다. 커밋만 하면 끝.

터미널파를 위한 한 줄 명령:
```bash
bash scripts/save.sh "루틴 카드 수정"
# 메시지 생략하면 날짜·시간이 들어갑니다
bash scripts/save.sh
```
VSCode에서는 **Cmd+Shift+B** 한 번이면 같은 동작을 합니다.

### 3단계 — 푸시하면 사이트 자동 배포
`.github/workflows/pages.yml`이 `main` 브랜치 푸시를 감지해 GitHub Pages에 올립니다.
공개 주소: `https://leelif2.github.io/Fitin_members/`
(비공개 repo면 Pages는 유료 플랜이 필요합니다. 그 경우 이 워크플로우 파일은 지우고 로컬 Live Server로 보세요.)

## 3. 완전 자동 (커밋도 자동)

커밋조차 하기 싫다면 백그라운드 감시를 켜세요 — 5분마다 변경분을 자동 커밋·푸시합니다.

```bash
bash scripts/autosave-watch.sh        # 5분 간격
bash scripts/autosave-watch.sh 60     # 1분 간격
```
VSCode: Cmd+Shift+P → "Tasks: Run Task" → **Watch & auto-commit**. 중지는 Ctrl-C.

커밋 이력이 지저분해지는 대가가 있으니, 평소엔 2단계를 쓰고 집중 작업 중에만 켜는 걸 권합니다.

## 3.5. Vercel 자동 배포

GitHub에 푸시하면 Vercel이 자동으로 새 버전을 올립니다. 최초 한 번만 연결하세요.

1. vercel.com → **Add New → Project** → `Leelif2/Fitin_members` import
2. Framework Preset: **Other**, Build Command 비움, Output Directory 비움 (정적 HTML)
3. Deploy

이후 `main`에 푸시할 때마다 자동 배포됩니다. 즉 **커밋 → 푸시 → 배포**가 한 줄로 이어집니다:

```bash
bash scripts/save.sh "로그인 페이지 수정"
```

주소:
- `/` → 온보딩 메인
- `/signin` 또는 `/login` → 로그인·회원가입

### Supabase 설정 (배포 후 필수)

로그인 페이지는 `https://fwoibsrnzgvmufgihtvv.supabase.co`의 Auth API를 직접 호출합니다. Vercel 도메인이 정해지면 Supabase 대시보드에서:

- **Authentication → URL Configuration → Site URL**: Vercel 도메인 입력
- **Redirect URLs**: 같은 도메인 추가 (이메일 확인 링크가 여기로 돌아옵니다)
- **Authentication → Providers → Email**: "Confirm email" 켜기 권장

보안 주의: anon key는 브라우저에 노출되는 공개 키입니다. 민감 데이터를 담을 모든 테이블에 **RLS(Row Level Security)를 반드시 켜고**, `auth.uid() = user_id` 정책을 거세요. RLS 없이 테이블을 만들면 anon key만으로 누구나 전체 데이터를 읽을 수 있습니다.

## 4. Claude Code와 함께 쓰기

설치 (한 번만):
```bash
npm install -g @anthropic-ai/claude-code
```

실행:
```bash
cd Fitin_members
claude
```

이 repo에는 Claude Code 설정이 이미 들어 있습니다:

| 파일 | 역할 |
| --- | --- |
| `CLAUDE.md` | 프로젝트 맥락, Nocturne 디자인 규칙, 보안 수칙 — 매 대화에 자동 주입 |
| `.claude/commands/save.md` | `/save` — 커밋 + 푸시 (Vercel 자동 배포까지) |
| `.claude/commands/new-screen.md` | `/new-screen` — 기존 페이지 규칙을 읽고 새 화면 추가 |
| `.claude/settings.json` | git 명령 실행 권한 미리 허용 (매번 승인 불필요) |

쓰는 법:
```
> routine 섹션에 주 5회 옵션 추가해줘
> /save
```

`/save`를 치면 Claude Code가 직접 커밋·푸시하고, Vercel이 배포합니다. 사용자가 누를 것은 없습니다.

`design_handoff_fitin_onboarding/README.md`는 온보딩 메인을 실제 앱(Next.js 등)으로 옮길 때 쓰는 전체 스펙입니다.

## 5. 저와 동기화

푸시한 뒤 이 대화에서 "sync"라고 말씀하시면, 제가 repo의 최신 상태를 읽어 다음 화면 디자인을 이어갑니다. `github.md`가 동기화 기록입니다.

## 파일 목록

| 파일 | 역할 |
| --- | --- |
| `.vscode/settings.json` | 파일 자동 저장, 커밋 후 자동 푸시, 자동 fetch |
| `.vscode/tasks.json` | Cmd+Shift+B = 저장·커밋·푸시 |
| `.vscode/extensions.json` | 권장 확장 프로그램 |
| `scripts/save.sh` | 한 줄로 add + commit + pull --rebase + push |
| `scripts/autosave-watch.sh` | N초마다 자동 커밋·푸시 |
| `.github/workflows/pages.yml` | 푸시 시 GitHub Pages 배포 |
| `.gitignore` | node_modules, .env, .DS_Store 제외 |
| `index.html` | 루트 접속 시 온보딩 메인으로 이동 |
