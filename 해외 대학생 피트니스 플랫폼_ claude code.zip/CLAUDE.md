# Fitin — 프로젝트 컨텍스트

해외 4개 대학(University of Utah Asia Campus, George Mason University Korea, SUNY Korea, Ghent University Global Campus) 학생을 위한 피트니스 스케줄링 서비스.

학생이 수업 시간표를 올리면 **2시간 이상 공강**을 찾아 레벨별(초급/중급/상급, 주 3~5회) 운동 루틴을 배정한다. Fitin 관리자가 **매주 일요일 21:00 KST**에 PT 예약 슬롯을 연다. PT 세션이 끝나면 피드백 구글폼(https://forms.gle/qcTqoCznB4gGMN9bA)이 참석 학생에게 자동 발송된다.

## Repo

- GitHub: `Leelif2/Fitin_members` (branch `main`)
- 배포: Vercel — `main` 푸시 시 자동 배포. `/` = 온보딩 메인, `/signin` = 로그인·회원가입
- 백엔드: Supabase `https://fwoibsrnzgvmufgihtvv.supabase.co` (Auth + DB)

## 파일 구조

| 파일 | 내용 |
| --- | --- |
| `Fitin Main.dc.html` | 온보딩 메인 (히어로, 스탯 밴드, 3단계, 루틴 레벨, PT 슬롯, 피드백 워크플로우) |
| `Fitin Auth.dc.html` | 로그인 / 회원가입 — Supabase Auth REST 직접 호출 |
| `_ds/nocturne-*/` | Nocturne 디자인 시스템 (토큰 + 컴포넌트 클래스) |
| `design_handoff_fitin_onboarding/README.md` | 온보딩 메인 전체 구현 스펙 |
| `scripts/save.sh` | add + commit + pull --rebase + push |
| `SETUP.md` | VSCode 자동저장 · Vercel · Supabase 설정 절차 |

`.dc.html` 파일은 Omelette 디자인 도구에서 만든 프로토타입이다. 상단 `<x-dc>` 안이 마크업(인라인 스타일), 하단 `class Component extends DCLogic`이 로직. `support.js`는 그 런타임이며 손대지 않는다.

## 디자인 규칙 (Nocturne)

색·타이포·간격·radius는 **전부** `_ds/nocturne-*/styles.css`의 `var(--*)` 토큰에서 가져온다. hex를 직접 쓰지 않는다.

- 바탕 `--color-bg` #161826 · 텍스트 `--color-text` #e9e9ed · 액센트 `--color-accent` #9184d9
- 버튼은 **아웃라인**, 채우지 않는다. 액센트를 넓은 면에 칠하지 않는다 (예외: `--color-section` 스탯 밴드)
- 본문 크기 액센트 텍스트는 `--color-accent-300` (액센트 자체는 대비 3:1이라 큰 글자·아이콘 전용)
- 제목 weight 500 고정, 위계는 크기와 여백으로
- 아이콘: Phosphor · 폰트: Inter
- 모든 다단 그리드는 `repeat(auto-fit, minmax(…, 1fr))` — 미디어 쿼리 없이 접히게. 360px부터 동작해야 한다
- 카피는 영어 우선, 한국어 보조 줄을 muted neutral로

## 작업 방식

- 파일을 고친 뒤에는 `bash scripts/save.sh "변경 요약"`으로 커밋·푸시한다. 사용자가 따로 요청하지 않아도 작업 단위가 끝나면 실행한다.
- 커밋 메시지는 한국어 또는 영어 한 줄, 무엇이 바뀌었는지만.
- 작은 수정 요청에는 그 부분만 고친다. 요청하지 않은 레이아웃·색·간격을 함께 바꾸지 않는다.
- 새 화면을 만들 때는 기존 두 페이지의 구조와 간격 규칙을 먼저 읽고 따른다.

## 보안

Supabase anon key는 브라우저에 노출되는 공개 키다. 회원·스케줄·세션 기록 테이블은 **전부 RLS를 켜고** `auth.uid() = user_id` 정책을 건다. 서비스 롤 키는 절대 클라이언트 코드에 넣지 않는다.

## 아직 만들지 않은 화면

시간표 업로드, 주간 캘린더(공강 뷰), 마이페이지/진행률, Fitin 관리자 콘솔.
